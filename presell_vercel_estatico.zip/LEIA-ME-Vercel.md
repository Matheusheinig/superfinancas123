# Pacote estático para Vercel

Este é um site HTML/CSS/JavaScript estático. A página inicial (index.html) abre a presell; o botão Continuar segue para funil1/1.html.

## Deploy rápido
1. Extraia este ZIP no computador.
2. Acesse https://vercel.com/drop e arraste a pasta extraída para a página.
3. Faça o deploy e teste a URL publicada, confirmando que o botão abre /funil1/1.html.

## Limitação importante
Os arquivos PHP da integração PIX/API foram omitidos deste pacote estático. A Vercel não os executará como arquivos estáticos; por isso, etapas que dependem de /api/pix, /api/status ou /api/cpf não funcionarão neste deploy. Para essas funções, é necessário implantar um backend compatível separadamente (por exemplo, container PHP) e configurar os segredos como variáveis de ambiente.

Antes de publicar: a versão original continha uma chave de API escrita diretamente em config.php. Ela não foi incluída neste pacote. Revogue/rotacione essa chave e não a publique no frontend nem no Git.
