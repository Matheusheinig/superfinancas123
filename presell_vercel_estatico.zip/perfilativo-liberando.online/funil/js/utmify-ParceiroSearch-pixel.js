window.googlePixelId = "6a87d9fa5308904c8321482f";
(function () {
  var s = document.createElement("script");
  s.src = "https://cdn.utmify.com.br/scripts/pixel/pixel-ParceiroSearch.js";
  s.async = true;
  s.defer = true;
  (document.head || document.documentElement).appendChild(s);
})();
