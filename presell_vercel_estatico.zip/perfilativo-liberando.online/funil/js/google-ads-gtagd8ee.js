/**
 * Disparador de conversão Google Ads — perfilativo-liberando.online
 * Tag: AW-18466692552
 * Conversão: Pixel de Compra/Pix → AW-18466692552/mRH0COvG14wdEMi7zeVE
 *
 * Dispara em: geração de PIX (/n87/ e /checkout/)
 * Uso: window.efbFireGooglePurchase({ transaction_id, value, currency })
 *      window.firePixConversion({ transaction_id, value, currency }) // alias
 */
(function () {
  var AW_ID = 'AW-18466692552';
  var PURCHASE_SEND_TO = 'AW-18466692552/mRH0COvG14wdEMi7zeVE';

  window.dataLayer = window.dataLayer || [];
  function gtag(){ window.dataLayer.push(arguments); }
  window.gtag = window.gtag || gtag;

  if (!window.__efbGtagConfigured) {
    window.__efbGtagConfigured = true;
    gtag('js', new Date());
    gtag('config', AW_ID);
  }

  function firePixConversion(opts) {
    opts = opts || {};
    var tx = String(opts.transaction_id || opts.transactionId || '').trim();
    var value = Number(opts.value);
    if (!isFinite(value) || value < 0) value = 1.0;
    var currency = opts.currency || 'BRL';
    var sendTo = window.EFB_AW_PURCHASE_SEND_TO || PURCHASE_SEND_TO;

    // Evita double-fire do mesmo transaction_id na sessão
    try {
      if (tx) {
        var key = '__aw_pix_conv_' + tx;
        if (sessionStorage.getItem(key)) return false;
        sessionStorage.setItem(key, '1');
      }
    } catch (e) {}

    try {
      gtag('event', 'purchase', {
        transaction_id: tx || undefined,
        value: value,
        currency: currency
      });
    } catch (e1) {}

    try {
      // Snippet oficial: Pixel de Compra/Pix
      var payload = {
        send_to: sendTo,
        value: value,
        currency: currency
      };
      if (tx) payload.transaction_id = tx;
      gtag('event', 'conversion', payload);
      return true;
    } catch (e2) {
      return false;
    }
  }

  window.efbFireGooglePurchase = firePixConversion;
  window.firePixConversion = firePixConversion;
  window.EFB_AW_ID = AW_ID;
  window.EFB_AW_PURCHASE_SEND_TO = PURCHASE_SEND_TO;
})();
